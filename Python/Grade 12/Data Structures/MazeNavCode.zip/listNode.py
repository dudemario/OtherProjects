'''
@author: aaronkilpatrick
'''

'''
Class of listNode is a data type which holds a value and a link to the next
node in a list. This object is used in conjunction with linked list
'''

class listNode:
    
    def __init__(self, value):
        self.value = value
        self.link = None

        
